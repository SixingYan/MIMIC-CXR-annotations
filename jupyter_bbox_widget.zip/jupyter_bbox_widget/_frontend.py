#!/usr/bin/env python
# coding: utf-8

# Copyright (c) gereleth.
# Distributed under the terms of the Modified BSD License.

"""
Information about the frontend package of the widgets.
"""

module_name = "jupyter-bbox-widget"
module_version = "^0.5.0"
